sudo apt-get install ros-hydro-octomap ros-hydro-octomap-ros ros-hydro-octomap-rviz-plugins ros-hydro-octomap-msgs ros-hydro-octovis

