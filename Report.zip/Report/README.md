ASL Student Templates
=====================

This repository is here to orient the students who conduct a project (Studies on Mechatronics, Bachelor-, Semester-, and Master Theses) at the Autonomous Systems Lab (ASL) at ETH Zurich. It contains general information, guidelines, templates and helpful links.

Head over to the [Wiki](https://github.com/ethz-asl/asl-student-templates/wiki) for more information or download the entire repository as a ZIP-file [here](https://github.com/ethz-asl/asl-student-templates/archive/master.zip).

ASL student projects are listed here: [http://www.asl.ethz.ch/education/student-projects.html](http://www.asl.ethz.ch/education/student-projects.html).
 
